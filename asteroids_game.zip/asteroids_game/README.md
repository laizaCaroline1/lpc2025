# Asteroids+
Projeto Asteroids+ — versão com inimigos pequenos e grandes, sons básicos e estrutura modular.
Rode `python game.py`. Precisa do pygame instalado:
```
pip install pygame
```
